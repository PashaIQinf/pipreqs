# Everything in here should be ignored
from pattern.web import Twitter, plaintext