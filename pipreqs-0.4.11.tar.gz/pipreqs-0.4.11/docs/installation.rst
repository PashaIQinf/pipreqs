============
Installation
============

At the command line::

    $ easy_install pipreqs

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv pipreqs
    $ pip install pipreqs
